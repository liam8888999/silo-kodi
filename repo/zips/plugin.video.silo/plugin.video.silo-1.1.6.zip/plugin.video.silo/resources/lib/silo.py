"""Silo /api/v2 client for Kodi.

This module is responsible for communicating with the Silo Server API.
Kodi UI/playback decisions live in main.py so the two responsibilities stay
separate and the code remains easier to maintain.

Important playback behaviour:
    * Silo is the source of truth for resume position.
    * main.py performs a fresh progress lookup immediately before playback.
    * The selected resume position is sent to POST /api/v2/playback/start as
      start_position so Kodi does not have to perform a second seek.
    * Kodi -> Silo progress is reported throughout playback.

Pagination is deliberately handled inside this client. Kodi never receives
or displays a "Next Page" item. The catalog and progress requests use the
maximum page size documented by the current Silo API where supported, reducing
the number of HTTP round trips for large libraries.

Endpoints used by this addon:
    POST /api/v2/auth/login
    POST /api/v2/auth/refresh
    GET  /api/v2/profiles
    POST /api/v2/profiles/{id}/verify-pin
    GET  /api/v2/user/libraries
    GET  /api/v2/catalog
    GET  /api/v2/catalog/series/{id}/seasons[/{n}/episodes]
    GET  /api/v2/catalog/items/{id}/versions
    GET  /api/v2/progress
    GET  /api/v2/playback/capabilities
    POST /api/v2/playback/start
    POST /api/v2/playback/{sid}/replan
    POST /api/v2/playback/{sid}/progress
    DELETE /api/v2/playback/{sid}
"""

# Standard library modules used for configuration, UUID generation and URL handling.
import base64
import json
import uuid
import threading
import time
from urllib.parse import quote

# requests is used for all API communication made by the addon itself.
import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


# Read addon metadata and determine where Kodi should store persistent configuration.
ADDON = xbmcaddon.Addon()
ADDON_VERSION = ADDON.getAddonInfo("version")

# Refresh slightly before JWT expiry so normal API calls do not hit an expired
# access token first. The server remains authoritative and the 401 path below
# is still kept as a final fallback for opaque tokens or clock differences.
ACCESS_TOKEN_REFRESH_MARGIN = 60

# Silo rotates refresh tokens on successful exchanges, so serialize refreshes
# across SiloClient instances in this Kodi process.
_REFRESH_LOCK = threading.Lock()


# Central logging helper so every log line identifies this addon.
def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[plugin.video.silo] %s" % msg, level)


# Window property used to keep the login loading indicator visible while the
# refreshed root directory is loading after a successful login.
_LOGIN_LOADING_PROPERTY = "Silo.LoginLoading"


def _show_login_loading():
    """Show Kodi's native non-cancelable busy spinner once for the login flow."""
    window = xbmcgui.Window(10000)

    # The login flow can pass through automatic profile selection, an explicit
    # profile chooser, and a post-login Container.Refresh. Keep one continuous
    # spinner instead of activating the busy dialog more than once.
    if window.getProperty(_LOGIN_LOADING_PROPERTY) == "true":
        return

    window.setProperty(_LOGIN_LOADING_PROPERTY, "true")

    # DialogBusy was removed as a usable Python class in Kodi 18+. The
    # supported workaround is to activate the non-cancelable busy-dialog
    # window explicitly.
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")

    # Allow Kodi's GUI thread to process and display the dialog before the
    # synchronous network request immediately following this call starts.
    xbmc.sleep(100)


def _hide_login_loading():
    """Close the login busy spinner and clear its refresh-state marker."""
    xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    xbmc.sleep(50)
    xbmcgui.Window(10000).clearProperty(_LOGIN_LOADING_PROPERTY)


# Load saved server/login/device/profile settings from Kodi's addon profile.
# Kodi's add-on settings are the persistent configuration store.
# The cfg dictionary remains an in-memory convenience for the rest of the
# client; it is never persisted to config.json.
_INTERNAL_SETTINGS = (
    "device_id",
    "token",
    "refresh_token",
    "profile_id",
    "profile_token",
)


def _setting(key, default=""):
    value = ADDON.getSetting(key)
    return value if value not in (None, "") else default


def _set_setting(key, value):
    ADDON.setSetting(key, "" if value is None else str(value))


def _clear_account_settings():
    """Clear editable login/profile settings and authentication state."""
    for key in (
        "server",
        "username",
        "device_id",
        "token",
        "refresh_token",
        "profile_id",
        "profile_token",
        "start_overrides",
    ):
        _set_setting(key, "")


def load_config():
    """Load all persistent add-on state from Kodi settings."""
    cfg = {}

    server = _setting("server").strip().rstrip("/")
    username = _setting("username").strip()
    profile = ""

    # Support username#profile in the username field.
    if "#" in username:
        username, inline_profile = username.split("#", 1)
        username = username.strip()
        profile = inline_profile.strip()

    if server:
        cfg["server"] = server
    if username:
        cfg["username"] = username
    if profile:
        cfg["profile_name"] = profile

    raw_items = _setting("items_per_page")
    try:
        cfg["items_per_page"] = max(20, min(int(raw_items or 200), 200))
    except (TypeError, ValueError):
        cfg["items_per_page"] = 200

    for key in _INTERNAL_SETTINGS:
        value = _setting(key)

        if not value:
            continue

        cfg[key] = value

    return cfg


def save_config(cfg):
    """Persist only hidden/internal runtime state into Kodi settings.

    Server and username are read-only settings and are already persisted by Kodi
    itself. Pagination is also handled directly by Kodi. These are deliberately
    not written here.
    """
    for key in _INTERNAL_SETTINGS:
        if key not in cfg:
            _set_setting(key, "")
            continue

        _set_setting(key, cfg[key])


# Custom exception used for errors that should be shown/logged by Kodi.
class SiloError(Exception):
    def __init__(self, msg, status=None, problem=None, retry_after=None):
        super().__init__(msg)
        self.status = status
        self.problem = problem or {}
        self.retry_after = retry_after


class SiloClient:
    """Small authenticated client for Silo's v2 API."""

    # Create the API client, load saved settings and create a stable Kodi device ID.
    def __init__(self):
        self.cfg = load_config()

        if not self.cfg.get("device_id"):
            self.cfg["device_id"] = "kodi-" + uuid.uuid4().hex[:16]
            _set_setting("device_id", self.cfg["device_id"])

        self.session = requests.Session()
        self._caps = None
        self._last_refresh_status = None
        self._last_refresh_problem = {}
        self._last_refresh_transient = False
        self.sync_settings()
        # Detail responses are reused when the same item is later played.
        self._details = {}

    # ------------------------------------------------------------ settings

    def sync_settings(self):
        """Refresh editable connection/profile settings from Kodi."""
        raw_username = ADDON.getSetting("username").strip()
        server = ADDON.getSetting("server").strip().rstrip("/")
        profile = ""

        username = raw_username

        if "#" in raw_username:
            username, inline_profile = raw_username.split("#", 1)
            username = username.strip()
            profile = inline_profile.strip()

        old_identity = (
            self.cfg.get("server", ""),
            self.cfg.get("username", ""),
            self.cfg.get("profile_name", ""),
        )
        new_identity = (
            server,
            username,
            profile,
        )

        if new_identity != old_identity:
            for key in ("token", "refresh_token", "profile_id", "profile_token"):
                self.cfg.pop(key, None)
            self._caps = None

        self.cfg["server"] = server if server else self.cfg.get("server", "")
        self.cfg["username"] = username if username else self.cfg.get("username", "")

        if profile:
            self.cfg["profile_name"] = profile
        else:
            self.cfg.pop("profile_name", None)

        # Server, username and profile are already persisted by Kodi's
        # settings store. Do not call save_config() here: doing so could clear
        # an internal token if Kodi has not yet exposed that setting value to
        # this Addon instance.



    # ------------------------------------------------------------ helpers

    # Base server URL used for every Silo API request.
    @property
    def base(self):
        return self.cfg.get("server", "").rstrip("/")

    # Convert relative Silo URLs such as /api/... into absolute URLs.
    def abs_url(self, url):
        if not url:
            return ""
        return self.base + url if url.startswith("/") else url

    # Build authentication/client headers required by Silo API endpoints.
    def _headers(self):
        # Kodi's settings store is authoritative. Read the live values
        # directly instead of relying on a potentially stale in-memory cfg.
        device_id = _setting("device_id")
        token = _setting("token")
        profile_id = _setting("profile_id")
        profile_token = _setting("profile_token")

        if not device_id:
            device_id = "kodi-" + uuid.uuid4().hex[:16]
            _set_setting("device_id", device_id)

        self.cfg["device_id"] = device_id

        h = {
            "Accept": "application/json",
            "X-Device-ID": device_id,
            "X-Client-Name": "plugin.video.silo",
            "X-Client-Version": ADDON_VERSION,
            "X-Client-Platform": "kodi",
        }

        if token:
            h["Authorization"] = "Bearer " + token
            self.cfg["token"] = token

        if profile_id:
            h["X-Profile-Id"] = str(profile_id)
            self.cfg["profile_id"] = str(profile_id)

        if profile_token:
            h["X-Profile-Token"] = str(profile_token)
            self.cfg["profile_token"] = str(profile_token)

        return h

    @staticmethod
    def _problem(r):
        """Create a readable message from a Silo problem+json response."""
        try:
            p = r.json()
        except ValueError:
            return "HTTP %s: %s" % (r.status_code, (r.text or r.reason)[:300])

        errors = p.get("errors") or []
        fields = [
            "%s [%s] %s" % (
                e.get("location", "?"),
                e.get("code", ""),
                e.get("detail", ""),
            )
            for e in errors[:8]
        ]

        head = p.get("detail") or p.get("title") or r.reason

        return "HTTP %s: %s%s" % (
            r.status_code,
            head,
            ("\n" + "\n".join(fields)) if fields else "",
        )

    # Send an authenticated API request and handle access-token/profile-token retries.
    def _send(self, method, path, params=None, body=None, need_profile=True, retry=True, timeout=30, log_not_found=True, extra_headers=None):
        if not self.base:
            self._prompt_account()

        if not _setting("token"):
            self.cfg.pop("token", None)

            # A stored refresh token is sufficient to restore an expired or
            # otherwise missing access token. Never ask for the password just
            # because Kodi restarted or the access token was lost locally.
            if _setting("refresh_token"):
                if not self.refresh():
                    if self._last_refresh_transient:
                        raise SiloError(
                            "Silo session refresh is temporarily unavailable; try again later."
                        )

                    # The server definitively rejected the refresh token, so
                    # this session can no longer be restored silently.
                    self.cfg.pop("token", None)
                    self.cfg.pop("refresh_token", None)
                    _set_setting("token", "")
                    _set_setting("refresh_token", "")
                    self.login()
            else:
                self.login()

        # Renew a JWT shortly before expiry so normal browsing/playback does
        # not wait for an expired-token 401 to trigger the refresh path.
        self.ensure_access_token_fresh()

        if need_profile and not self.cfg.get("profile_id"):
            self.select_profile()

        try:
            headers = self._headers()
            if extra_headers:
                headers.update(extra_headers)

            r = self.session.request(
                method,
                self.base + path,
                headers=headers,
                params=params,
                json=body,
                timeout=timeout,
            )
        except requests.RequestException as e:
            raise SiloError("Cannot reach server: %s" % e)

        # A 401 may mean the access token has expired. Refresh it and retry once.
        if r.status_code == 401 and retry:
            if not self.refresh():
                # Do not throw away a potentially valid session when the
                # refresh failed because of a transient network/server issue.
                if self._last_refresh_transient:
                    raise SiloError(
                        "Silo session refresh is temporarily unavailable; try again later.",
                        r.status_code,
                        {},
                    )

                # A definitive refresh-token refusal means the server has
                # ended this session. Start a fresh credential login.
                self.cfg.pop("token", None)
                self.cfg.pop("refresh_token", None)
                _set_setting("token", "")
                _set_setting("refresh_token", "")
                save_config(self.cfg)
                self.login()

            return self._send(
                method,
                path,
                params,
                body,
                need_profile,
                False,
                timeout,
                log_not_found,
                extra_headers,
            )

        # A locked profile may need a fresh profile-verification token.
        if r.status_code == 403 and retry and "profile_verification" in r.text:
            self.cfg.pop("profile_token", None)
            self.verify_profile(self.cfg.get("profile_id"))
            return self._send(
                method,
                path,
                params,
                body,
                need_profile,
                False,
                timeout,
                log_not_found,
                extra_headers,
            )

        if not r.ok:
            if not (r.status_code == 404 and not log_not_found):
                log(
                    "%s %s -> %s" % (method, path, r.text[:1200]),
                    xbmc.LOGWARNING,
                )

            try:
                problem = r.json()
            except ValueError:
                problem = {}

            retry_after = r.headers.get("Retry-After")
            raise SiloError(
                self._problem(r),
                r.status_code,
                problem,
                retry_after,
            )

        return r

    # Convenience wrapper that sends a request and decodes the JSON response.
    def _json(self, *args, **kwargs):
        r = self._send(*args, **kwargs)
        return r.json() if r.content else None

    # --------------------------------------------------------------- auth

    # Ask for the server and username the first time the addon is configured.
    def _prompt_account(self):
        dlg = xbmcgui.Dialog()

        server = dlg.input(
            "Silo server URL (e.g. http://host:8090)",
            defaultt="http://",
        )

        if not server:
            raise SiloError("Login cancelled")

        user = dlg.input(
            "Silo username",
            defaultt="",
        )

        if not user:
            raise SiloError("Login cancelled")

        # A '#' is optional. Without it, retain the normal profile-selection
        # dialog. With it, use the part before '#' as the account username and
        # the part after '#' as the profile name.
        server = server.rstrip("/")
        user = user.strip()

        ADDON.setSetting("server", server)
        ADDON.setSetting("username", user)

        if "#" in user:
            username, profile_name = user.split("#", 1)
            username = username.strip()
            profile_name = profile_name.strip()

            if not username or not profile_name:
                ADDON.setSetting("server", "")
                ADDON.setSetting("username", "")
                raise SiloError(
                    "Use username#profile, for example liam1#liam2"
                )

            ADDON.setSetting("username", username)
            self.cfg["username"] = username
            self.cfg["profile_name"] = profile_name
            self._requested_profile_name = profile_name
        else:
            self.cfg["username"] = user
            self.cfg.pop("profile_name", None)
            self._requested_profile_name = ""

        self.cfg["server"] = server
        save_config(self.cfg)

    # Store the access/refresh token pair returned by Silo.
    def _store_tokens(self, data):
        access_token = str(data.get("access_token") or "")
        refresh_token = str(data.get("refresh_token") or "")

        if not access_token or not refresh_token:
            raise SiloError("Silo login did not return authentication tokens")

        self.cfg["token"] = access_token
        self.cfg["refresh_token"] = refresh_token

        # Persist authentication immediately in Kodi's settings store.
        _set_setting("token", access_token)
        _set_setting("refresh_token", refresh_token)

        log("Silo authentication tokens saved to Kodi settings")

    # Authenticate directly with /auth/login.
    #
    # This deliberately does NOT call _send(), because _send() calls login()
    # when a token is missing. Calling _send() here would recurse forever.
    def login(self, show_loading=False):
        if not self.base or not self.cfg.get("username"):
            self._prompt_account()

        # Never leave the busy dialog covering an input prompt. The loading
        # indicator starts only after the password has been submitted.
        _hide_login_loading()

        pw = xbmcgui.Dialog().input(
            "Password for %s" % self.cfg["username"],
            option=xbmcgui.ALPHANUM_HIDE_INPUT,
        )

        if not pw:
            raise SiloError("Login cancelled")

        # Start Kodi's native busy spinner immediately after the password
        # prompt closes, before the network authentication request begins.
        if show_loading:
            _show_login_loading()

        try:
            r = self.session.post(
                self.base + "/api/v2/auth/login",
                timeout=20,
                headers={
                    "Accept": "application/json",
                    "X-Device-ID": self.cfg["device_id"],
                    "X-Client-Name": "plugin.video.silo",
                    "X-Client-Version": ADDON_VERSION,
                    "X-Client-Platform": "kodi",
                },
                json={
                    "username": self.cfg["username"],
                    "password": pw,
                    "provider": "",
                },
            )
        except requests.RequestException as e:
            if show_loading:
                _hide_login_loading()
            raise SiloError("Cannot reach server: %s" % e)

        if not r.ok:
            if show_loading:
                _hide_login_loading()
            raise SiloError("Login failed - " + self._problem(r))

        try:
            self._store_tokens(r.json())
        except Exception:
            if show_loading:
                _hide_login_loading()
            raise

    # Complete interactive login used by the Kodi Login button.
    #
    # This intentionally performs the whole initial-login sequence in one
    # place: server/username/password, token storage, profile selection and
    # profile PIN verification when required.
    def login_full(self):
        # Explicit login starts with no busy spinner so the server, username
        # and password prompts are unobstructed.
        _hide_login_loading()

        # Every explicit Kodi login starts as a completely fresh attempt.
        # Do not reuse a previously entered server, username, token or profile
        # after a failed/cancelled login; this ensures the next attempt always
        # starts at the server URL prompt.
        for key in (
            "server",
            "username",
            "token",
            "refresh_token",
            "profile_id",
            "profile_token",
        ):
            self.cfg.pop(key, None)

        self._caps = None
        self._requested_profile_name = ""
        for key in ("token", "refresh_token", "profile_id", "profile_token"):
            _set_setting(key, "")
        save_config(self.cfg)

        try:
            # login() now asks for server URL, username and password from
            # scratch because no account fields were retained above.
            self.login(show_loading=True)

            # Keep the spinner active when the account can select its
            # profile automatically. select_profile() pauses it only when Kodi
            # actually needs to display a profile or PIN prompt.
            self.select_profile()

        except SiloError:
            # Always close the loading indicator on a failed or cancelled login.
            _hide_login_loading()

            # A bad password, unknown user/server, cancelled prompt, cancelled
            # profile selection, or cancelled PIN must leave no partial login
            # state behind. The next Login selection will start at server URL.
            for key in (
                "server",
                "username",
                "token",
                "refresh_token",
                "profile_id",
                "profile_token",
            ):
                self.cfg.pop(key, None)

            self._caps = None
            self._requested_profile_name = ""
            for key in ("token", "refresh_token", "profile_id", "profile_token"):
                _set_setting(key, "")
            save_config(self.cfg)
            raise

    # Exchange the saved refresh token for a new access token.
    def refresh(self):
        """Rotate the Silo access/refresh pair without prompting for a password."""
        with _REFRESH_LOCK:
            # A different SiloClient (or another Kodi process) may have
            # already rotated the refresh token. Re-read persistent settings
            # before every exchange and retry once when a newer token appears.
            for attempt in range(2):
                rt = _setting("refresh_token") or self.cfg.get("refresh_token")
                if not rt or not self.base:
                    self._last_refresh_status = None
                    self._last_refresh_problem = {}
                    self._last_refresh_transient = False
                    return False

                try:
                    r = self.session.post(
                        self.base + "/api/v2/auth/refresh",
                        headers={
                            "Accept": "application/json",
                            "X-Device-ID": _setting("device_id") or self.cfg["device_id"],
                            "X-Client-Name": "plugin.video.silo",
                            "X-Client-Version": ADDON_VERSION,
                            "X-Client-Platform": "kodi",
                        },
                        json={"refresh_token": rt},
                        timeout=20,
                    )
                except requests.RequestException as exc:
                    self._last_refresh_status = None
                    self._last_refresh_problem = {}
                    self._last_refresh_transient = True
                    log("Silo token refresh unavailable: %s" % exc, xbmc.LOGWARNING)
                    return False

                self._last_refresh_status = r.status_code

                try:
                    problem = r.json() if not r.ok else {}
                except ValueError:
                    problem = {}

                if not r.ok:
                    self._last_refresh_problem = problem
                    log("Silo refresh response status=%d type=%s detail=%s" % (r.status_code, problem.get("type") or "", problem.get("detail") or ""), xbmc.LOGWARNING)
                    self._last_refresh_transient = (
                        r.status_code >= 500 or r.status_code in (408, 429)
                    )

                    # Refresh tokens rotate. If another client won the
                    # exchange between our reads, the server rejects the
                    # old token even though the session is still valid.
                    latest_rt = _setting("refresh_token")
                    if (
                        attempt == 0
                        and r.status_code == 401
                        and latest_rt
                        and latest_rt != rt
                    ):
                        log(
                            "Silo refresh token was rotated elsewhere; retrying with the current token",
                            xbmc.LOGWARNING,
                        )
                        continue

                    log(
                        "Silo token refresh failed -> %s %s"
                        % (
                            r.status_code,
                            problem.get("detail") or problem.get("title") or "",
                        ),
                        xbmc.LOGWARNING,
                    )
                    return False

                try:
                    data = r.json()
                    self._store_tokens(data)
                except (ValueError, SiloError) as exc:
                    self._last_refresh_problem = {}
                    self._last_refresh_transient = True
                    log(
                        "Silo token refresh returned an invalid response: %s" % exc,
                        xbmc.LOGWARNING,
                    )
                    return False

                log("Silo access token refreshed automatically")
                return True

            return False


    def ensure_access_token_fresh(self):
        """Refresh the access token shortly before a JWT expires."""
        token = str(_setting("token") or self.cfg.get("token") or "").strip()
        if not token:
            return False

        self.cfg["token"] = token
        expiry = self.access_token_expiry()
        if expiry is None:
            return True

        if expiry - time.time() > ACCESS_TOKEN_REFRESH_MARGIN:
            return True

        # Another request may already have refreshed while this client was
        # waiting. The refresh lock makes the token rotation safe.
        if self.refresh():
            return True

        # A failed refresh must not turn a temporary network/server problem
        # into a password prompt. Keep the current access token and let the
        # request below decide whether the server still accepts it.
        return True

    # Fully log the account out locally.
    #
    # Server and username are deliberately removed as well as the tokens and
    # profile information. This makes the next use a completely fresh login,
    # allowing the user to enter a different server and/or username instead of
    # being forced to reuse the previous account. The stable Kodi device ID is
    # intentionally retained so Silo still recognises this Kodi installation
    # as the same device after logging into another account.
    def logout(self):
        # Clear the editable account settings from Kodi itself as well as the
        # in-memory client state. Keeping these values would cause the next
        # addon launch to use the settings-first login path and ask only for
        # the password.
        for key in (
            "server",
            "username",
            "token",
            "refresh_token",
            "profile_id",
            "profile_token",
        ):
            self.cfg.pop("server" if key == "server" else key, None)
            _set_setting(key, "")

        # Keep the stable device ID, but discard account/profile-specific state.
        self.cfg.pop("profile_name", None)
        self._caps = None
        self._requested_profile_name = ""

        log("Silo account settings and authentication state cleared")

    # Return the access-token expiry without logging or exposing the token.
    # Silo currently uses JWT access tokens. Decoding the payload is sufficient
    # here because this value is only used as a local scheduling hint; the server
    # remains authoritative for authentication and every API call still handles
    # 401 by refreshing normally.
    def access_token_expiry(self):
        token = str(self.cfg.get("token") or _setting("token") or "").strip()
        if not token:
            return None

        try:
            parts = token.split(".")
            if len(parts) != 3:
                return None

            payload = parts[1]
            payload += "=" * (-len(payload) % 4)
            decoded = base64.urlsafe_b64decode(payload.encode("ascii"))
            claims = json.loads(decoded.decode("utf-8"))
            expiry = claims.get("exp")
            if expiry is None:
                return None

            return float(expiry)
        except (ValueError, TypeError, UnicodeError, json.JSONDecodeError):
            return None
        except Exception:
            return None

    # ----------------------------------------------------------- profiles

    # Load household profiles and remember the selected profile.
    def select_profile(self):
        data = self._json(
            "GET",
            "/api/v2/profiles",
            need_profile=False,
        )

        profiles = (data or {}).get("items", [])

        if not profiles:
            raise SiloError("This account has no profiles")

        requested_name = str(
            getattr(self, "_requested_profile_name", "")
            or self.cfg.get("profile_name", "")
            or ""
        ).strip()

        if requested_name:
            chosen = next(
                (
                    profile
                    for profile in profiles
                    if str(profile.get("name", "")).strip().casefold()
                    == requested_name.casefold()
                ),
                None,
            )

            if chosen is None:
                raise SiloError(
                    "Profile '%s' was not found. Use username#profile."
                    % requested_name
                )
        elif len(profiles) == 1:
            # There is no profile chooser to display, so leave the login
            # spinner active and select the only profile automatically.
            chosen = profiles[0]
        else:
            # A real profile-selection dialog needs to be visible to the user,
            # so temporarily close the login spinner while Kodi displays it.
            _hide_login_loading()

            idx = xbmcgui.Dialog().select(
                "Who's watching?",
                [p.get("name", "Profile") for p in profiles],
            )

            if idx < 0:
                raise SiloError("No profile selected")

            chosen = profiles[idx]

            # Resume the existing login spinner once profile selection is done.
            _show_login_loading()

        self.cfg["profile_id"] = str(chosen["id"])
        self.cfg.pop("profile_token", None)

        # Persist profile selection directly in Kodi's settings store so a
        # new plugin invocation can immediately reuse the selected profile.
        _set_setting("profile_id", self.cfg["profile_id"])
        _set_setting("profile_token", "")

        # The selected profile ID is stored internally. The visible settings
        # page intentionally has no editable profile-name field.

        if chosen.get("has_pin"):
            # The PIN prompt must be visible, so pause the spinner for it and
            # resume the same login spinner afterwards.
            _hide_login_loading()
            try:
                self.verify_profile(chosen["id"])
            finally:
                _show_login_loading()

    # Verify a PIN-locked profile and store its temporary verification token.
    def verify_profile(self, profile_id):
        pin = xbmcgui.Dialog().input(
            "Profile PIN",
            type=xbmcgui.INPUT_NUMERIC,
            option=xbmcgui.ALPHANUM_HIDE_INPUT,
        )

        if not pin:
            raise SiloError("PIN required")

        data = self._json(
            "POST",
            "/api/v2/profiles/%s/verify-pin" % profile_id,
            body={"pin": pin},
            need_profile=False,
        )

        if not data or not data.get("valid"):
            raise SiloError("Wrong PIN")

        self.cfg["profile_token"] = data.get("profile_token", "")
        _set_setting("profile_token", self.cfg["profile_token"])

    # ------------------------------------------------------------ browsing

    @staticmethod
    def _next(data):
        """Return the next API cursor, or None when the current page is final."""
        page = (data or {}).get("page") or {}
        return page.get("next_cursor") if page.get("has_more") else None

    # Return every library visible to the current profile. API pagination is hidden from Kodi.
    def libraries(self):
        libraries = []
        cursor = None

        while True:
            data = self._json(
                "GET",
                "/api/v2/user/libraries",
                params={"cursor": cursor} if cursor else None,
            ) or {}

            libraries.extend(data.get("items", []))

            cursor = self._next(data)
            if not cursor:
                return libraries


    # Return the profile-wide Home sections. These combine content across
    # all libraries visible to the selected profile.
    def home_sections(self, image_size="medium"):
        data = self._json(
            "GET",
            "/api/v2/home/sections",
            params={"image_size": image_size},
        ) or {}
        return data.get("sections", [])

    # Return one profile-wide Home section and its cards.
    def home_section_items(self, section_id, image_size="medium"):
        data = self._json(
            "GET",
            "/api/v2/home/sections/%s/items"
            % quote(str(section_id), safe=""),
            params={"image_size": image_size},
        ) or {}
        return data

    # Return one Home section through Silo's full catalog-card endpoint.
    # Unlike /home/sections/{id}/items, this response uses CatalogItem and
    # includes added_at. For Recently Added TV sections, Silo's resolver sets
    # that timestamp to the episode/event that caused the series to be recent.
    def home_section_catalog_items(self, section_id, image_size="medium", limit=200):
        """Return full catalog cards for one profile-scoped Home section."""
        try:
            limit = max(1, min(int(limit or 200), 200))
        except (TypeError, ValueError):
            limit = 200

        data = self._json(
            "GET",
            "/api/v2/catalog",
            params={
                "source": "section",
                "scope": "home",
                "section_id": section_id,
                "limit": limit,
                "skip_total": "true",
                "image_size": image_size,
            },
        ) or {}

        # The stable v2 catalog response is normally the collection itself.
        # Accept a body envelope as well for compatibility with older builds.
        if isinstance(data, dict) and isinstance(data.get("body"), dict):
            data = data["body"]

        return data

    # Search the profile-visible catalog across all accessible libraries.
    # Silo performs the search server-side, so the addon does not need to
    # download and scan every library itself.
    def search_people(self, query, limit=20):
        """Search profile-visible Silo people by name."""
        query = str(query or "").strip()
        if not query:
            return []

        try:
            limit = max(1, min(int(limit or 20), 100))
        except (TypeError, ValueError):
            limit = 20

        data = self._json(
            "GET",
            "/api/v2/catalog/people",
            params={
                "q": query,
                "limit": limit,
            },
        ) or {}

        return data.get("items", [])

    def person_catalog_page(self, person_id, cursor=None, limit=200):
        """Return one page of profile-visible media credited to a person."""
        person_id = str(person_id or "").strip()
        if not person_id:
            return [], None

        limit = max(1, min(int(limit or 200), 200))

        params = {
            "source": "person",
            "person_id": person_id,
            "limit": limit,
            "skip_total": "true",
            "image_size": "medium",
        }

        if cursor:
            params["cursor"] = cursor

        data = self._json(
            "GET",
            "/api/v2/catalog",
            params=params,
        ) or {}

        return (
            data.get("items", []),
            self._next(data),
        )

    def search_catalog(self, query, limit=100, offset=0):
        """Return one page of Silo's v2 server-side catalog search results.

        Keep the add-on's existing page/offset interface, but translate the
        offset into Silo v2's explicit zero-based seek. The v2 catalog already
        supplies the same profile-scoped search results plus cursor metadata,
        so no v1 compatibility endpoint is needed.
        """
        query = str(query or "").strip()
        if not query:
            return {"items": [], "has_more": False, "total": 0}

        try:
            limit = max(1, min(int(limit or 100), 100))
        except (TypeError, ValueError):
            limit = 100

        try:
            offset = max(0, int(offset or 0))
        except (TypeError, ValueError):
            offset = 0

        params = {
            "source": "query",
            "q": query,
            "limit": limit,
            "skip_total": "true",
            "image_size": "medium",
        }

        # Silo v2 uses seek for a direct jump to the requested zero-based
        # result window. Page 1 naturally starts at position zero, so omit it.
        if offset:
            params["seek"] = offset

        data = self._json(
            "GET",
            "/api/v2/catalog",
            params=params,
        ) or {}

        page = data.get("page") or {}

        return {
            "items": data.get("items") or [],
            "has_more": bool(page.get("has_more")),
            "total": data.get("total", 0),
            "total_exact": bool(data.get("total_exact", False)),
            "next_cursor": page.get("next_cursor"),
            "window_cursor": data.get("window_cursor"),
        }

    # Join an existing Watch Party. Kodi intentionally exposes no
    # room-creation operation: this client is participant-only.
    def watch_party_join(self, code=None, join_token=None):
        body = {}

        if str(code or "").strip():
            body["code"] = str(code).strip().upper()

        if str(join_token or "").strip():
            body["join_token"] = str(join_token).strip()

        if not body:
            raise SiloError("A Watch Party code or invite token is required.")

        return self._json(
            "POST",
            "/api/v2/watch-together/join",
            body=body,
        ) or {}

    # Mint a single-use room socket ticket. The original room proof remains in
    # X-Room-Token; Silo does not accept room credentials in the WebSocket URL.
    def watch_party_socket_ticket(self, room_id, room_token):
        if not room_id or not room_token:
            raise SiloError("Watch Party room credentials are missing.")

        data = self._json(
            "POST",
            "/api/v2/watch-together/rooms/%s/ws-ticket"
            % quote(str(room_id), safe=""),
            extra_headers={
                "X-Room-Token": str(room_token),
            },
        ) or {}

        protocol = str(data.get("protocol") or "")
        ticket = str(data.get("ticket") or "")

        if protocol != "silo.room.v2" or len(ticket) != 43:
            raise SiloError("Silo returned an invalid Watch Party socket credential.")

        return data

    # Return one page from a profile-wide personal catalog source.
    # This is the same catalog surface the Silo web client uses for Favorites,
    # Watchlist and History, preserving the server's source ordering and cursor.
    def personal_catalog_page(self, source, cursor=None, limit=200, collection_id=None):
        source = str(source or "").strip().lower()
        if source not in ("favorites", "watchlist", "history", "user_collection"):
            raise SiloError("Unsupported personal catalog source: %s" % source)

        limit = max(1, min(int(limit or 200), 200))

        params = {
            "source": source,
            "limit": limit,
            "skip_total": "true",
            "image_size": "medium",
        }

        if cursor:
            params["cursor"] = cursor

        if collection_id:
            params["collection_id"] = collection_id

        data = self._json(
            "GET",
            "/api/v2/catalog",
            params=params,
        ) or {}

        return (
            data.get("items", []),
            self._next(data),
        )

    # Return the profile's visible personal collections and collection groups.
    def collections(self):
        data = self._json(
            "GET",
            "/api/v2/collections",
        ) or {}

        return (
            data.get("items", []),
            data.get("groups", []),
        )

    # Return every catalog item in a library while handling pagination internally.
    # Silo's current API documents a maximum catalog page size of 200, so use
    # that maximum to reduce the number of HTTP round trips for large libraries.
    def catalog_page(self, library_id, cursor=None, limit=200,
                     name_prefix=None, sort=None, seek=None):
        """Return one Silo catalog page and its continuation cursor."""
        limit = max(1, min(int(limit or 200), 200))

        params = {
            "library_id": library_id,
            "limit": limit,
            "skip_total": "true",
            "image_size": "medium",
        }

        if name_prefix:
            params["name_prefix"] = str(name_prefix)
        if sort:
            params["sort"] = str(sort)
        if seek is not None:
            try:
                params["seek"] = max(0, int(seek))
            except (TypeError, ValueError):
                params["seek"] = 0
        if cursor:
            params["cursor"] = cursor

        data = self._json(
            "GET",
            "/api/v2/catalog",
            params=params,
        ) or {}

        return (
            data.get("items", []),
            self._next(data),
        )

    # Return one server-side alphabet page and its total/has-more information.
    def catalog_prefix_page(self, library_id, name_prefix, offset=0,
                            limit=200, include_total=False):
        """Return one indexed title-prefix page using Silo's seek support."""
        prefix = str(name_prefix or "").strip()
        if not prefix:
            return [], 0, False, False

        try:
            offset = max(0, int(offset or 0))
        except (TypeError, ValueError):
            offset = 0

        limit = max(1, min(int(limit or 200), 200))

        data = self._json(
            "GET",
            "/api/v2/catalog",
            params={
                "library_id": library_id,
                "limit": limit,
                "skip_total": "false" if include_total else "true",
                "image_size": "medium",
                "name_prefix": prefix,
                "sort": "title",
                "seek": offset,
            },
        ) or {}

        try:
            total = int(data.get("total") or 0)
        except (TypeError, ValueError):
            total = 0

        total_exact = bool(data.get("total_exact"))
        page = data.get("page") or {}

        return (
            data.get("items", []),
            total,
            total_exact,
            bool(page.get("has_more")),
        )


    def catalog(self, library_id, limit=200):
        items = []
        cursor = None

        while True:
            page_items, cursor = self.catalog_page(
                library_id,
                cursor=cursor,
                limit=limit,
            )

            items.extend(page_items)

            if not cursor:
                return items

    # Return all seasons for a series.
    def seasons(self, series_id, library_id=None, suppress_not_found=False):
        data = self._json(
            "GET",
            "/api/v2/catalog/series/%s/seasons" % quote(series_id, safe=":"),
            params={"library_id": library_id} if library_id else None,
            log_not_found=not suppress_not_found,
        ) or {}

        return data.get("items", [])

    # Return all episodes for one series season.
    def episodes(self, series_id, season_number, library_id=None):
        data = self._json(
            "GET",
            "/api/v2/catalog/series/%s/seasons/%s/episodes"
            % (quote(series_id, safe=":"), season_number),
            params={"library_id": library_id} if library_id else None,
        ) or {}

        return data.get("items", [])

    # Return the complete detail document for one catalog item.
    #
    # Unlike the browse/catalog card, this endpoint includes cast, crew and
    # full file-version track metadata. Results are cached for the lifetime of
    # this Kodi directory request so play() can reuse the same detail document.
    def item_detail(self, content_id, library_id=None, file_id=None):
        key = (
            str(content_id),
            str(library_id) if library_id is not None else "",
            str(file_id) if file_id is not None else "",
        )

        if key in self._details:
            return self._details[key]
        # The detail endpoint also prepares cast/crew artwork. Kodi only        # needs small thumbnails for these person images, which keeps the
        # metadata response substantially smaller for large libraries.
        params = {"image_size": "small"}

        if library_id:
            params["library_id"] = library_id
        if file_id:
            params["file_id"] = file_id

        data = self._json(
            "GET",
            "/api/v2/catalog/items/%s" % quote(content_id, safe=":"),
            params=params or None,
        ) or {}

        self._details[key] = data
        return data

    # Return the playable versions/files for one catalog item.
    def versions(self, content_id, library_id=None):
        data = self._json(
            "GET",
            "/api/v2/catalog/items/%s/versions" % quote(content_id, safe=":"),
            params={"library_id": library_id} if library_id else None,
        ) or {}

        return data.get("items", [])

    # ------------------------------------------------------------ progress

    # Retrieve every server-side progress record, hiding pagination from Kodi.
    def progress(self, library_id=None, status=None):
        records = []
        cursor = None

        while True:
            # The current Silo progress endpoint supports up to 200 records
            # per page, which reduces round trips when the fresh playback check
            # scans the server's progress collection.
            params = {"limit": 200}

            if library_id:
                params["library_id"] = library_id

            if status:
                params["status"] = status

            if cursor:
                params["cursor"] = cursor

            data = self._json(
                "GET",
                "/api/v2/progress",
                params=params,
            ) or {}

            records.extend(data.get("items", []))

            cursor = self._next(data)
            if not cursor:
                return records

    # Return only in-progress records for a library.
    #
    # The catalog already tells us which items are fully played. To display
    # accurate partial-watch markers we only need the smaller in_progress subset
    # rather than downloading the entire progress history.
    def in_progress(self, library_id=None):
        return self.progress(
            library_id=library_id,
            status="in_progress",
        )

    # Build a lookup map containing the newest in-progress record for each item.
    def in_progress_map(self, library_id=None):
        result = {}

        for record in self.in_progress(library_id=library_id):
            media_id = record.get("media_item_id")
            if media_id is None:
                continue

            key = str(media_id)
            existing = result.get(key)

            if (
                not existing
                or (record.get("updated_at") or "")
                > (existing.get("updated_at") or "")
            ):
                result[key] = record

        return result

    # Return the newest Silo progress record for one catalog media item.
    def get_progress(self, content_id, library_id=None):
        matches = [
            record
            for record in self.progress(library_id=library_id)
            if str(record.get("media_item_id")) == str(content_id)
        ]

        if not matches:
            return None

        # Silo returns newest-change-first, but sorting explicitly means this
        # method remains correct even if the API ordering changes later.
        matches.sort(
            key=lambda record: record.get("updated_at") or "",
            reverse=True,
        )

        return matches[0]

    # Build a single lookup map containing the newest record for each media item.
    def progress_map(self, library_id=None):
        result = {}

        for record in self.progress(library_id=library_id):
            media_id = record.get("media_item_id")
            if media_id is None:
                continue

            key = str(media_id)
            existing = result.get(key)

            if not existing or (record.get("updated_at") or "") > (existing.get("updated_at") or ""):
                result[key] = record

        return result

    # ------------------------------------------------------------ playback

    # Fetch and cache the playback capabilities advertised by Silo.
    def playback_caps(self):
        if self._caps is None:
            self._caps = self._json(
                "GET",
                "/api/v2/playback/capabilities",
                need_profile=False,
            ) or {}

        return self._caps

    # Identify this Kodi installation in playback requests.
    def _installation_id(self):
        return self.playback_caps().get("installation_id") or self.cfg["device_id"]

    # Pick the highest protocol version supported by both the server metadata and our fallback.
    def _protocol_version(self):
        versions = self.playback_caps().get("protocol_versions") or [3]

        try:
            return max(int(version) for version in versions)
        except (TypeError, ValueError):
            return 3

    # Build a protocol-v3 playback/start request.
    def _start_body(self, file_id, start_position=0.0, quality_preference="original", direct_play_only=False):
        caps = self.playback_caps()
        pv = self._protocol_version()

        # JellyCon deliberately does not restrict DirectPlayProfiles by codec,
        # container, resolution or decoder. Silo's current v3 planner requires
        # non-empty flat capability lists for its direct-play eligibility gate,
        # so use a broad Kodi software-playback vocabulary here rather than
        # attempting to guess the capabilities of the current hardware.
        #
        # These are compatibility declarations, not hardware-acceleration
        # claims. Direct playback remains preferred by Silo whenever the source
        # matches these broad capabilities; otherwise Silo can fall through to
        # remux/transcode.
        video = [
            "h264",
            "hevc",
            "vp9",
            "av1",
            "mpeg2video",
            "mpeg4",
            "vc1",
        ]
        audio = [
            "aac",
            "ac3",
            "eac3",
            "dts",
            "truehd",
            "flac",
            "opus",
            "mp3",
            "vorbis",
            "pcm",
        ]
        containers = [
            "mkv",
            "mp4",
            "avi",
            "ts",
            "webm",
            "mov",
        ]

        delivery_template = {
            "enabled": True,
            "supported_on_device": True,
            "containers": containers,
            "video_codecs": video,
            "audio_decode_codecs": audio,
            "audio_passthrough_codecs": [],
            "subtitles": {
                "embedded_text": True,
                "sidecar_text": True,
                "ass_styling": True,
                "embedded_bitmap": True,
                "sidecar_bitmap": True,
                "font_attachments": True,
            },
            "features": [],
            "auth_header_refresh": False,
            "validated_claims": [],
            "transformations": [],
        }

        # Preserve the server-advertised delivery objects where available.
        # Silo maps its server delivery names to these client classes:
        # original_http, progressive and hls.
        server_deliveries = caps.get("deliveries") or {}

        if isinstance(server_deliveries, dict):
            deliveries = {
                name: dict(value)
                if isinstance(value, dict)
                else dict(delivery_template)
                for name, value in server_deliveries.items()
            }
        else:
            deliveries = {
                name: dict(delivery_template)
                for name in server_deliveries
            }

        # Direct-play classes use the broad compatibility declaration above.
        original_delivery = deliveries.get(
            "original_http",
            dict(delivery_template),
        )
        original_delivery.update(delivery_template)
        deliveries["original_http"] = original_delivery

        progressive_delivery = deliveries.get(
            "progressive",
            dict(delivery_template),
        )
        progressive_delivery.update(delivery_template)
        deliveries["progressive"] = progressive_delivery

        # HLS is only the fallback/transcode path. Silo's validated HLS
        # transcode recipe produces H.264 video and AAC audio.
        hls_delivery = deliveries.get(
            "hls",
            dict(delivery_template),
        )
        hls_delivery["containers"] = ["hls"]
        hls_delivery["video_codecs"] = ["h264"]
        hls_delivery["audio_decode_codecs"] = ["aac"]
        hls_delivery["audio_passthrough_codecs"] = []
        deliveries["hls"] = hls_delivery

        if direct_play_only:
            # In direct-play-only mode, tell Silo that transcoding/remux-style
            # delivery is not an acceptable fallback. The returned plan is
            # still validated below, so this remains fail-closed if a server
            # ignores or does not understand the delivery declaration.
            original_delivery["enabled"] = True
            original_delivery["supported_on_device"] = True
            progressive_delivery["enabled"] = False
            progressive_delivery["supported_on_device"] = False
            hls_delivery["enabled"] = False
            hls_delivery["supported_on_device"] = False

        return {
            "installation_id": self._installation_id(),
            "protocol_version": pv,
            "client_features": ["playback_plan_v3", "seek_reanchor_v1"],
            "file_id": str(file_id),
            "profile_id": str(self.cfg["profile_id"]),
            "start_position": float(start_position),
            "playback_attempt_id": uuid.uuid4().hex,
            "quality_preference": str(quality_preference or "original"),
            "subtitle_fidelity_preference": "preserve",
            "metered": False,
            "progress_persistence": "server",
            "client_capabilities": {
                "video_evidence": "declared",
                "audio_evidence": "declared",
                "codecs_video": video,
                "codecs_video_hardware": [],
                "codecs_audio": audio,
                "containers": containers,
                "hdr": True,
            },
            "client_playback_context": {
                "protocol_version": pv,
                "form_factor": "desktop",
                "app_version": ADDON_VERSION,
                "device": {
                    "platform": "kodi",
                    "manufacturer": "",
                    "model": "",
                    "os_version": xbmc.getInfoLabel("System.OSVersionInfo"),
                },
                "output": {},
                "deliveries": deliveries,
            },
        }


    # Replan an active session when the player reports sustained network trouble.

    # Silo owns the quality decision; Kodi only supplies the current position and

    # an observed effective bandwidth estimate.

    def replan_playback(self, info, position, bandwidth_estimate_kbps, quality_preference="auto", operation="failure_recovery", failure=None):

        plan = (info or {}).get("playback_plan") or {}
        session_id = (info or {}).get("session_id") or plan.get("session_id")

        if not session_id or not plan:
            raise SiloError("Cannot replan playback without an active Silo plan.")

        try:
            bandwidth_estimate_kbps = int(bandwidth_estimate_kbps)
        except (TypeError, ValueError):
            raise SiloError("Invalid bandwidth estimate for playback replan.")

        bandwidth_estimate_kbps = max(100, min(bandwidth_estimate_kbps, 1000000))

        playback_attempt_id = str((info or {}).get("playback_attempt_id") or "")
        plan_attempt_id = str((info or {}).get("plan_attempt_id") or "")

        if not playback_attempt_id or not plan_attempt_id:
            raise SiloError("Playback replan state is incomplete.")

        current_plan_key = str(plan.get("plan_attempt_key") or "")

        # Failure recovery uses attempted-plan loop prevention. Explicit
        # quality changes are a fresh intent and must start a new replan chain.
        is_failure_recovery = str(operation or "failure_recovery") in (
            "failure_recovery",
            "seek_failure_recovery",
        )

        if is_failure_recovery:
            attempted_plan_keys = list((info or {}).get("attempted_plan_keys") or [])
            if current_plan_key and current_plan_key not in attempted_plan_keys:
                attempted_plan_keys.append(current_plan_key)
            attempted_plan_keys = attempted_plan_keys[-16:]

            try:
                attempt_count = int((info or {}).get("attempt_count") or 1) + 1
            except (TypeError, ValueError):
                attempt_count = 2

            attempt_count = max(1, min(attempt_count, 8))
        else:
            attempted_plan_keys = []
            attempt_count = 1

        # Silo requires every failure_recovery replan to carry a failure
        # classification. Enforce that here as a final safeguard so callers
        # cannot accidentally produce a malformed recovery request.
        if str(operation or "failure_recovery") in (
            "failure_recovery",
            "seek_failure_recovery",
        ) and not failure:
            failure = {
                "classification": "playback_recovery",
                "message": "Kodi requested recovery from the current playback plan.",
            }

        body = {
            "installation_id": self._installation_id(),
            "protocol_version": 3,
            "client_features": ["playback_plan_v3"],
            "operation": str(operation or "failure_recovery"),
            "playback_attempt_id": playback_attempt_id,
            "replan_request_id": uuid.uuid4().hex,
            "failed_plan_id": str(plan.get("plan_id") or ""),
            "plan_attempt_id": plan_attempt_id,
            "plan_attempt_key": current_plan_key,
            "attempted_plan_keys": attempted_plan_keys,
            "attempt_count": attempt_count,
            "quality_preference": str(quality_preference or "auto"),
            "position_seconds": max(0.0, float(position or 0.0)),
            "metered": bool((info or {}).get("metered", False)),
            "bandwidth_estimate_kbps": bandwidth_estimate_kbps,
            "selected_tracks": plan.get("selected_tracks") or {},
            "client_capabilities": (info or {}).get("client_capabilities") or {},
            "client_playback_context": (info or {}).get("client_playback_context") or {},
            **({"failure": failure} if failure else {}),
        }

        data = self._json(
            "POST",
            "/api/v2/playback/%s/replan" % session_id,
            body=body,
            timeout=90,
        ) or {}

        new_plan = data.get("playback_plan")
        if not new_plan:
            terminal = data.get("terminal") or data.get("outcome")
            raise SiloError(
                "Silo could not adapt playback: %s" % json.dumps(terminal)[:400],
                problem=terminal if isinstance(terminal, dict) else {},
            )

        stream = new_plan.get("stream") or {}
        url = self.abs_url(stream.get("url"))

        if not url:
            raise SiloError("Silo returned an adaptive plan without a stream URL.")

        headers = dict(stream.get("headers") or {})
        auth_headers = self._headers()

        for key in ("Authorization", "X-Profile-Id", "X-Profile-Token"):
            value = auth_headers.get(key)
            if value and key not in headers:
                headers[key] = value

        if headers:
            url += "|" + "&".join(
                "%s=%s" % (key, quote(str(value), safe=""))
                for key, value in headers.items()
            )

        log(
            "adaptive replan delivery=%s quality=%s client_bandwidth_hint_kbps=%d (recipe-based, not measured throughput) position=%.3f"
            % (
                new_plan.get("delivery"),
                quality_preference or "auto",
                bandwidth_estimate_kbps,
                float(position or 0.0),
            )
        )

        return {
            "url": url,
            "session_id": data.get("session_id") or session_id,
            "playback_plan": new_plan,
            "playback_attempt_id": playback_attempt_id,
            "plan_attempt_id": plan_attempt_id,
            "attempted_plan_keys": attempted_plan_keys,
            "attempt_count": attempt_count,
            "metered": bool((info or {}).get("metered", False)),
            "client_capabilities": (info or {}).get("client_capabilities") or {},
            "client_playback_context": (info or {}).get("client_playback_context") or {},
        }

    # Reopen the current transport with fresh authentication at the same
    # playback position. The seek_reanchor operation preserves the selected
    # media version, tracks, quality and route semantics while issuing a new
    # stream URL containing the current access token.
    def refresh_playback_stream_auth(self, info, position):
        plan = (info or {}).get("playback_plan") or {}
        session_id = (info or {}).get("session_id") or plan.get("session_id")

        if not session_id or not plan:
            raise SiloError("Cannot refresh playback authentication without an active Silo plan.")

        playback_attempt_id = str((info or {}).get("playback_attempt_id") or "")
        plan_attempt_id = str((info or {}).get("plan_attempt_id") or "")
        plan_attempt_key = str(plan.get("plan_attempt_key") or "")

        if not playback_attempt_id or not plan_attempt_id or not plan_attempt_key:
            raise SiloError("Playback reauthentication state is incomplete.")

        quality_preference = str(
            (info or {}).get("quality_preference")
            or plan.get("quality_preference")
            or "original"
        )

        recipe = plan.get("effective_recipe") or {}
        try:
            current_bitrate = int(recipe.get("bitrate_kbps") or 0)
        except (TypeError, ValueError):
            current_bitrate = 0

        body = {
            "installation_id": self._installation_id(),
            "protocol_version": 3,
            "client_features": (info or {}).get("client_features") or ["playback_plan_v3"],
            "operation": "seek_reanchor",
            "playback_attempt_id": playback_attempt_id,
            "replan_request_id": str(uuid.uuid4()),
            "failed_plan_id": str(plan.get("plan_id") or ""),
            "plan_attempt_id": plan_attempt_id,
            "plan_attempt_key": plan_attempt_key,
            "attempted_plan_keys": [],
            "attempt_count": 1,
            "quality_preference": quality_preference,
            "position_seconds": max(0.0, float(position or 0.0)),
            "metered": bool((info or {}).get("metered", False)),
            "bandwidth_estimate_kbps": max(100, current_bitrate) if current_bitrate else 1500,
            "selected_tracks": plan.get("selected_tracks") or {},
            "client_capabilities": (info or {}).get("client_capabilities") or {},
            "client_playback_context": (info or {}).get("client_playback_context") or {},
        }

        data = self._json(
            "POST",
            "/api/v2/playback/%s/replan" % session_id,
            body=body,
            timeout=90,
        ) or {}

        new_plan = data.get("playback_plan")
        if not new_plan:
            terminal = data.get("terminal") or data.get("outcome")
            raise SiloError(
                "Silo could not refresh the playback stream: %s" % json.dumps(terminal)[:400],
                problem=terminal if isinstance(terminal, dict) else {},
            )

        stream = new_plan.get("stream") or {}
        url = self.abs_url(stream.get("url"))
        if not url:
            raise SiloError("Silo returned a refreshed playback plan without a stream URL.")

        headers = dict(stream.get("headers") or {})
        auth_headers = self._headers()
        for key in ("Authorization", "X-Profile-Id", "X-Profile-Token"):
            value = auth_headers.get(key)
            if value and key not in headers:
                headers[key] = value

        if headers:
            url += "|" + "&".join(
                "%s=%s" % (key, quote(str(value), safe=""))
                for key, value in headers.items()
            )

        return {
            "url": url,
            "session_id": data.get("session_id") or session_id,
            "playback_plan": new_plan,
            "file_id": (info or {}).get("file_id"),
            "playback_attempt_id": playback_attempt_id,
            "plan_attempt_id": plan_attempt_id,
            "attempted_plan_keys": [],
            "attempt_count": 1,
            "metered": bool((info or {}).get("metered", False)),
            "quality_preference": quality_preference,
            "client_features": body.get("client_features") or [],
            "client_capabilities": body.get("client_capabilities") or {},
            "client_playback_context": body.get("client_playback_context") or {},
        }
    # Find playback fields mentioned by Silo's validation error.
    @staticmethod
    def _invalid_fields(err):
        errors = err.problem.get("errors") or []
        text = " ".join(
            "%s %s" % (
                e.get("location", ""),
                e.get("detail", ""),
            )
            for e in errors
        ).lower()

        return [
            field
            for field in _VOCAB
            if field.lower() in text
        ]

    # Ask Silo for a playable stream URL using the supplied server-authoritative start position.
    def start_playback(self, file_id, start_position=0.0, quality_preference="original", direct_play_only=False):
        body = self._start_body(
            file_id,
            start_position,
            quality_preference=quality_preference,
            direct_play_only=direct_play_only,
        )

        data = self._json(            "POST",
            "/api/v2/playback/start",
            body=body,
        )

        plan = data.get("playback_plan")

        if not plan:
            raise SiloError(
                "Server refused playback: %s"
                % json.dumps(data.get("terminal") or data.get("outcome"))[:300]
            )

        if direct_play_only and str(plan.get("delivery") or "").strip().lower() != "original_http":
            raise SiloError(
                "Direct play only is enabled, but Silo selected %s delivery." %
                (plan.get("delivery") or "an unsupported")
            )

        stream = plan.get("stream") or {}
        url = self.abs_url(stream.get("url"))

        if not url:
            raise SiloError("Silo returned a playback plan without a stream URL.")

        # Kodi's VideoPlayer uses its own HTTP client rather than the Python
        # requests.Session above. Include both stream-specific headers from Silo
        # and the account/profile headers needed to open the stream endpoint.
        headers = dict(stream.get("headers") or {})
        auth_headers = self._headers()

        for key in ("Authorization", "X-Profile-Id", "X-Profile-Token"):
            value = auth_headers.get(key)
            if value and key not in headers:
                headers[key] = value

        # Kodi supports per-URL HTTP headers with |Header=value&Header2=value.
        if headers:
            url += "|" + "&".join(
                "%s=%s" % (key, quote(str(value), safe=""))
                for key, value in headers.items()
            )

        log(
            "delivery=%s protocol=%s outcome=%s start_position=%.3f"
            % (
                plan.get("delivery"),
                stream.get("protocol"),
                data.get("outcome"),
                float(start_position),
            )
        )

        return {
            "url": url,
            "session_id": data.get("session_id") or plan.get("session_id"),
            "playback_plan": plan,
            "file_id": str(file_id),
            "playback_attempt_id": body.get("playback_attempt_id"),
            "client_features": body.get("client_features") or [],
            # Preserve the requested quality so a seek_reanchor can reproduce
            # the attempt's intent while the server keeps its current frozen route.
            "quality_preference": str(quality_preference or "original"),
            # plan_attempt_id is client-owned; keep one stable ID for all
            # replans in this playback session, matching Silo's other clients.
            "plan_attempt_id": uuid.uuid4().hex,
            "attempted_plan_keys": [],
            "attempt_count": 1,
            "metered": bool(body.get("metered", False)),
            "client_capabilities": body.get("client_capabilities") or {},
            "client_playback_context": body.get("client_playback_context") or {},
        }

    # Mint the v2 owner-bound control-socket credential used by the web player.
    def playback_control_socket_ticket(self, session_id):
        if not session_id:
            raise SiloError("Playback session ID is required.")

        data = self._json(
            "POST",
            "/api/v2/playback/sessions/%s/control/ws-ticket" % session_id,
            body={
                "installation_id": self._installation_id(),
            },
            timeout=10,
            log_not_found=False,
        ) or {}

        ticket = str(data.get("ticket") or "")
        protocol = str(data.get("protocol") or "")
        if (
            not ticket
            or protocol != "silo.playback-control.v2"
        ):
            raise SiloError("Silo returned an invalid playback control credential.")

        return data

    # Send the current Kodi playback position to Silo.
    def report_progress(self, session_id, sequence, position, paused):
        self._send(
            "POST",
            "/api/v2/playback/%s/progress" % session_id,
            body={
                "installation_id": self._installation_id(),
                "sequence": int(sequence),
                "position": float(position),
                "is_paused": bool(paused),
            },
        )

    # Tell Silo that the playback session ended.
    def stop_playback(self, session_id, sequence, position):
        # Silo requires stop_id to be a canonical UUID, not uuid.uuid4().hex.
        stop_id = str(uuid.uuid4())

        self._send(
            "DELETE",
            "/api/v2/playback/%s" % session_id,
            body={
                "installation_id": self._installation_id(),
                "stop_id": stop_id,
                "sequence": int(sequence),
                "position": float(position),
                "is_paused": False,
            },
        )
